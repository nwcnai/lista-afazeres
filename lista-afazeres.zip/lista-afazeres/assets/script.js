
// definimos as variaveis
var form = document.querySelector("form"); // puxa o form do HTML para o JS
var input = document.querySelector("#tarefa"); // puxa o id tarefa (HTML)
var lista = document.querySelector("#lista"); // puxa o id lista (HTML)

// adicionando as tarefas
function adicionarTarefa(evento) {
  evento.preventDefault();


  var tarefa = input.value.trim();
  // trim remove espaço no final e no inicio do input (valor inserido pelo usuario)
  

  // se a tarefa estiver com algo preenchido (não vazia) faça o que está abaixo:
  if (tarefa !== "") {

    // criar a lista com o texto da tarefa
    var item = document.createElement("li");
    var texto = document.createTextNode(tarefa);

    // cria e adiciona o elemento botão "remover"
    var botaoRemover = document.createElement("button");
    botaoRemover.classList.add("remover");
    botaoRemover.innerText = "Remover";

    // se clicar no botão, ele remove a tarefa.
    botaoRemover.addEventListener("click", removerTarefa);

    // exibe o conteúdo do elemento na página
    item.appendChild(texto);

    // add um novo elemento HTML ao elemento "item".
    item.appendChild(botaoRemover);
    lista.appendChild(item);

    input.value = "";
    input.focus();
  }
}

// marcar como feita
function marcarFeito() {
  var item = this.parentNode;
  item.classList.toggle("feito");
}

// remover tarefas
function removerTarefa() {
  var item = this.parentNode;
  var pai = item.parentNode;

  pai.removeChild(item);
}

// "armazenando" o envio dos dados
form.addEventListener("submit", adicionarTarefa);

botaoFeito.innerText = "Feito";
